print('My name is')
for i in range(5):
    print('Jimmy Five Times (' + str(i) + ')')